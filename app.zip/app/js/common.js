$(document).ready(function() {


    $("#button-top").click(function() {
        if ($(".nav").is(':visible')){
            $(".nav").fadeOut(600);
        }
        else{
            $(".nav").fadeIn(600);
        }
        $('#button-top').toggleClass('toggle');

    });

    $(".nav ul a").click(function() {
        if ($(".nav").is(':visible')){
            $(".nav").fadeOut(600);
        }
        else{
            $(".nav").fadeIn(600);
        }
        $('#button-top').toggleClass('toggle');

    });$(document).ready(function() {


    $("#button-top").click(function() {
        if ($(".nav").is(':visible')){
            $(".nav").fadeOut(600);
        }
        else{
            $(".nav").fadeIn(600);
        }
        $('#button-top').toggleClass('toggle');

    });

    $(".nav ul a").click(function() {
        if ($(".nav").is(':visible')){
            $(".nav").fadeOut(600);
        }
        else{
            $(".nav").fadeIn(600);
        }
        $('#button-top').toggleClass('toggle');

    });

    $('.owl-carousel').owlCarousel({
        Number: 1,
        center: true,
        loop:true, //Зацикливаем слайде
        autoplay:true, //Автозапуск слайдера
        smartSpeed:1000, //Время движения слайда
        autoWidth: true,
        nav: true,
        pagination : true,
        autoplayTimeout:5000, //Время смены слайда
        responsive: true,
        responsiveBaseWidth: window,
        responsive:{ //Адаптивность. Кол-во выводимых элементов при определенной ширине.
            0:{
                items: 1
            },
            600:{
                items: 2
            },
            1000:{
                items: 4
            }
        }
    });
});


